#!/bin/bash


java -Xms512M -Xmx512M -Xss1024K -XX:PermSize=256m -XX:MaxPermSize=512m \
     -cp KafkaOffsetMonitor-assembly-0.4.6-SNAPSHOT.jar \
     com.quantifind.kafka.offsetapp.OffsetGetterWeb \
     --offsetStorage zookeeper \
     --kafkaBrokers localhost:9092 \
     --kafkaSecurityProtocol PLAINTEXT \
     --zk localhost:2181 \
     --port 8787 \
     --refresh 10.seconds \
     --retain 7.days 1>/home/bigdata/kafkamonitor/stdout.log 2>/home/bigdata/kafkamonitor/stderr.log  \
     --dbName offsetapp_kafka &

echo "OK....."