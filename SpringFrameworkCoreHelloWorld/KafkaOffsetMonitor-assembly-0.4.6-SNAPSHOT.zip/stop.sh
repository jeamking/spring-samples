#!/bin/bash

killnum=`jps | grep OffsetGetterWeb | awk '{print $1}'`
kill -9 ${killnum}
echo "OK....."
